function [ave_pprs, uppr_totaltime, upprme] = UPPR_e5(a, c, s, ncon, nparts, src, tar)
pre_com = tic;
    % %% flattening
     n = size(a,1);
    % 
    % %tar = cat(1,tar{:});
    % % no. of certain and uncertain edges
    % ncedges = nnz(a);
    % nucedges = size(src, 2);
    % 
    % % each outgoing edge is associated with 1/(c+u) transition prob.
    % certransposs = 1 / (ncedges + nucedges);
    % 
    % 
    % % each uncertain edge without non-existence is given a transition
    % % prob. (1/t)x(1/(c+u))
    % a1 = a;
    % for i = 1:size(src,2)
    % 
    %      ntargets = size(tar{i},2);
    %      uncertransposs{i} = (1/ntargets) * certransposs;
    % 
    %      for j = 1:ntargets
    %          if tar{i}(j)~=0
    %             a1(src(i),tar{i}(j)) = (1/ntargets) * certransposs;
    %             %a1(tar{i}(j), src(i)) = (1/ntargets) * certransposs;
    % 
    %          end
    %      end
    % end
    % 
    % addtransposs = sum(cell2mat(uncertransposs));
    % 
    % % uncertain edge 中有non-exist 
    % if any(cellfun(@(x) any(x == 0), tar))
    %     % 无certain edge
    %     if ncedges == 0
    %         a1(a1 ~= 0) = a1(a1 ~= 0) + (addtransposs * (1 / nucedges));
    %        % disp(w)
    %     else
    %         % 有certain edge
    %         a1(a == 1) = certransposs + addtransposs;
    % 
    %     end
    % else
    %       % uncertain edge 中没有non-exist
    %      a1(a == 1) = certransposs;
    % end

    %% enumerate possible uncertainity and sum of all uncertainity as P
    pw = cell(1, numel(tar));
    [pw{:}] = ndgrid(tar{:});
    tars = cell2mat(cellfun(@(v)v(:), pw, 'UniformOutput',false));

    npw = size(tars, 1); 
    n = size(a,1);
    P = sparse(n,n);

    tic
    for i = 1:npw
        %tmp = sparse(n,n);

        for j = 1:numel(src)
            if tars(i,j)
                 tmp = P(src(j), tars(i,j));
                 P(src(j), tars(i,j)) = tmp + 1;
            end
        end
    end

    %% Inverse certainity
    % column normalization of certain transition matrix
    d = full(sum(a,2));      % in-degree vector
    d_inv = 1./d;
    d_inv(~isfinite(d_inv)) = 0;
    w = a' * spdiags(d_inv, 0, n, n);
   
    [xadj, adjncy] = coo2csr(a|a');
    partition = METIS_PartGraphKway(n,ncon,xadj,adjncy,[],[],[],nparts,[],[],[]);
    [par,ix] = sort(partition);

    v0 = find(diff([-1 par]));
    nparts = numel(v0);
    
    [Tbl,x] = blockDiagGraph(w, par,ix, nparts);
    Tx = w - Tbl;
    [Q_inv,~] = block_inv(x, c, nparts);
    
    Tbl =sparse(Tbl);

    Tx = sparse(Tx);
    
    Q_inv = sparse(Q_inv);
    
    %% Compute UPPR
    
   %  p2 = npw * Tx * Q_inv * Tx;
   %  %fprintf('p2 Memory required: %f\n', size(p2,2)^2*8/1024^3);
   %  %disp(issparse(p2));
   % 
   %  p3 = P * Q_inv * Tx;
   %  %fprintf('p3 Memory required: %f\n', size(p3,2)^2*8/1024^3);
   % % disp(issparse(p3));
   % 
   %  p23 = p2 + p3;
   %  %clear p2 p3
   % 
   %  p4 =  Tx * Q_inv * P;
   %  %fprintf('p4 Memory required: %f\n', size(p4,2)^2*8/1024^3);
   %  %disp(issparse(p4));
   % 
   %  p234 = p23 + p4;
   %  %clear p23 p4
   % 
   %  p1 = npw * Tx + P;
   %  %fprintf('p1 Memory required: %f\n', size(p1,2)^2*8/1024^3);
   %  %disp(issparse(p1));
   % 
   %  ps = p1 + c * p234;
   %  %clear p1 p234
   % 
   %  %fprintf('ps Memory required: %f\n', size(ps,2)^2*8/1024^3);
   %  %disp(issparse(ps));
   % 
   %  I = speye(n, n);
   %  qps = I + (c/npw) * Q_inv * ps;
   %  %fprintf('qps Memory required: %f\n', size(qps,2)^2*8/1024^3);
   %  %disp(issparse(qps));
   % 
   %  % clear ps
   %  % disp('clear')
   % 
   %  qpsq = qps * Q_inv;
   %  % disp(issparse(qpsq));
   %  % fprintf('qpsq Memory required: %f\n', size(qpsq, 2)^2*8/1024^3);
   % 
   %  pre_com = (1-c) * qpsq;
   %  % fprintf('pre_com Memory required: %f\n', size(pre_com,2)^2*8/1024^3);
    
    UPPR_precom_time = toc(pre_com)
    % 
    % pprs = [];
    % 
    % tic
    % for i =1: size(s,2)
    %     ppr = pre_com * s(:,i);
    %     pprs = [pprs ppr/norm(ppr)];
    % 
    % end
    % query_time = toc                                                                                                                  
    
    query_time = tic;
    pprs = 0;
    for i = 1: size(s,2)
        Z = Q_inv *s(:,i);
        Y = Tx * Z; % Tx * Q_inv *s(:,i)
        X = Q_inv * Y; % Q_inv * Tx * Q_inv *s(:,i)

        r1 = (1-c) * Z;
        r2 = c*(1-c) * X;
        r3 = 1/n *  c *(1-c)* (Q_inv * (P * Z));
        r4 =  c^2 * (1-c) * (Q_inv * (Tx * X));
        r5 = 1/n * c^2 * (1-c) *(Q_inv *(P * X));
        r6 = 1/n * c^2 * (1-c) *(Q_inv *(Tx*(Q_inv*(P * Z))));
        ppr = r1 + r2 + r3 + r4 + r5 + r6;
        pprs = pprs + ppr; 
    end

    qtime = toc(query_time);
    qu_num = size(s,2);
    ave_pprs = pprs / qu_num;
    ave_pprs = ave_pprs/norm(ave_pprs);
    
    uppr_totaltime = qtime + UPPR_precom_time;
    
    me = whos;
    bytes = [me.bytes].';
    upprme = sum(bytes)
end
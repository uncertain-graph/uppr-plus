function [ave_pprs, collApx2me] = collApx2_ppr(a, c, qu_set, src, tar,ncon,nparts)
    num_qu_set = numel(qu_set);
    num_src = numel(src);

    %% enumerate all target set of possible worlds
    pw = cell(1, numel(tar));
    [pw{:}] = ndgrid(tar{:});
    tars = cell2mat(cellfun(@(v)v(:), pw, 'UniformOutput',false));
    
    npw =size(tars,2);

    m = size(a,2);
   
    par = {};
    norm_w1 = sparse(m,m);
    norm_w2 = sparse(m,m);

    tic
    
    for i = 1 : npw
        a1 = a;
        for j = 1: num_src
            if tars(i,j) 
                a1(src(j),tars(i,j)) = 1;
            end
        end
        %% Compute BIN of each possible world.
        [xadj, adjncy] = coo2csr(a1|a1');

        % column norm
        n = size(a1,1);    % # of nodes
        d = full(sum(a1,2));      % in-degree vector
        % d(~d)=1;
        % w = a1/spdiags(d',0,n,n);
        d_inv = 1./d;
        d_inv(~isfinite(d_inv)) = 0;
        w = a1' * spdiags(d_inv, 0, n, n);
        
        partition = METIS_PartGraphKway(n,ncon,xadj,adjncy,[],[],[],nparts,[],[],[]);
        
        % sort group no., return with the previous indice
        [par{i},ix] = sort(partition);
        
        %if any(diff(par))
        [w1, ~] = blockDiagGraph(w, par{i}, ix, nparts);

        norm_w2 =  norm_w2 + (w - w1);
        norm_w1 = norm_w1 + w1;
    end
    w12_preCompute = toc
    
    tic

    w1 = norm_w1 / npw;
    w2 = norm_w2 / npw;
    
    % column norm
    n = size(a,1);    % # of nodes
    d = full(sum(a));      % in-degree vector
    d(~d)=1;
    w = a/spdiags(d',0,n,n);

    %%% block w1 using the partition of the last pw %%%
    %[~, x] = blockDiagGraph(w, par{1},ix, nparts);

    %[Q_inv, ~] = block_inv(x, c, nparts);
    I = speye(n,n);
    Q_inv = inv(I - c * w1);

    rank_k =min(50, sprank(w2));
    [U,S,V] = svds(w2, rank_k);

    temp = inv(inv(S) - c * V' * Q_inv*U);

    pprs = 0;
   
    %% Query 
    % tic
    Z = c * Q_inv * U * temp * V';

    coll2pre_comTime = toc
    
    tic 
     for qu = 1 : num_qu_set
        nqu = numel(qu_set{qu});
        qu_vec = sparse(qu_set{qu}', 1, 1/nqu, n, 1);

        x = Q_inv * qu_vec;
        rwr = (1-c) * (x + Z * x);

         % associative law
         %rwr = (1-c) * (Q_inv*s(:,i) + (c*Q_inv*U * temp) * (V'*Q_inv*s(:,i))); 
         

         pprs =pprs + rwr;
    end
    ave_pprs = pprs/num_qu_set;

    coll2_querytime = toc
    me = whos;
    bytes = [me.bytes].';
    collApx2me = sum(bytes)
end
function [pprs, collme] = coll_ppr_v1(a, c, qu_set, src, tar, kmax)
    num_qu_set = numel(qu_set);

    %% enumerate all target set of possible worlds
    pw = cell(1, numel(tar));
    [pw{:}] = ndgrid(tar{:});
    tars = cell2mat(cellfun(@(v)v(:), pw, 'UniformOutput',false));
    
    npw = size(tars,1);
    
    n = size(a, 2);
    
    T =sparse(n,n);
   % tic
    for i = 1 : npw
        if mod(i,5)==0
            disp(i)
        end
        a1 = a;
        for j = 1: numel(src)
            if tars(i,j)
                %tmp = unc_a(src(j),tars(i,j));
                a1(src(j),tars(i,j)) =  1;
            end
        end
        n = size(a1,1);    
        d = full(sum(a1,2));      
        d_inv = 1./d;
        d_inv(~isfinite(d_inv)) = 0;
        w = a1' * spdiags(d_inv, 0, n, n);

        T = T+w;

    end
    
    %% compute average ppr
    T = T/ npw;

    col_preCompPW_time = toc
    
    pprs = 0;
    tic
    for qu = 1: num_qu_set
        nqu = numel(qu_set{qu});
        qu_vec = sparse(qu_set{qu}', 1, 1/nqu, n, 1);

        [ppr, ppriterme] = iter_ppr(c, T, qu_vec, kmax);
        pprs = pprs + ppr;
    end
    pprs = pprs/num_qu_set;
  
    
    col_querytime = toc
  
    me = whos;
    bytes = [me.bytes].';
    collme = sum(bytes)+ppriterme;
end
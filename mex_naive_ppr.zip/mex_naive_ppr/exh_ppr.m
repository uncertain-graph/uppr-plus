function [ave_pprs, exhme] = exh_ppr(a, c, s, src, tar, kmax)
   total = tic;
    %% enumerate all target set of possible worlds
    pw = cell(1, numel(tar));
    [pw{:}] = ndgrid(tar{:});
    tars = cell2mat(cellfun(@(v)v(:), pw, 'UniformOutput',false));
    
    %% compute average ppr
    npw =length(tars);
    pwppr = 0;
    qppr = 0;
 
    memo = 0;
    for p = 1 : size(s,2)
        for i = 1 : npw
            a1 = a;
            for j = 1 : numel(src) 
                if tars(i,j) 
                    a1(src(j),tars(i,j)) = 1;
                end
            end
            
            % column norm
             n = size(a1,1);    % # of nodes
             d = full(sum(a1,2));      % in-degree vector
             % d(~d)=1;
             % w = a1/spdiags(d, 0, n, n);
             d_inv = 1./d;
             d_inv(~isfinite(d_inv)) = 0;
             w = a1' * spdiags(d_inv, 0, n, n);
             [ppr, ppriterme] = iter_ppr(c, w, s(:,p), kmax);
             pwppr = pwppr + ppr;
            
             memo = memo + ppriterme;
        end

        pwppr = pwppr / npw;

        qppr = qppr + pwppr;
        
    end
    ave_pprs = qppr / size(s,2);
    ave_pprs = ave_pprs/norm(ave_pprs);
    total_time = toc(total)
    
    me = whos;
    bytes = [me.bytes].';
    exhme = sum(bytes) + memo



function [ave_pprs, flatme] = flat_ppr(a, c, qu_set, src, tar, kmax)
    num_qu_set = numel(qu_set);
    num_src = numel(src);
    tic
    n = size(a,1);
    
    %tar = cat(1,tar{:});
    % no. of certain and uncertain edges
    ncedges = nnz(a);
    nucedges = size(src, 2);
    
    % each outgoing edge is associated with 1/(c+u) transition prob.
    certiansposs = 1 / (ncedges + nucedges);
    
    
    % each uncertain edge without non-existence is given a transition
    % prob. (1/t)x(1/(c+u))
    a1 = a;
    for i = 1 : num_src

         ntargets = size(tar{i},2);
         uncertransposs{i} = (1/ntargets) * certiansposs;

         for j = 1:ntargets
             if tar{i}(j)~=0
                 
                a1(src(i),tar{i}(j)) = (1/ntargets) * certiansposs;
                %a1(tar{i}(j), src(i)) = (1/ntargets) * certransposs;
                
             end
         end
    end

    addtransposs = sum(cell2mat(uncertransposs));

    % uncertain edge 中有non-exist 
    if any(cellfun(@(x) any(x == 0), tar))
        % 无certain edge
        if ncedges == 0
            a1(a1 ~= 0) = a1(a1 ~= 0) + (addtransposs * (1 / nucedges));
           % disp(w)
        else
            % 有certain edge
            [row,col] = find(a1);
            for i = 1:numel(row)
              a1(row(i), col(i))= certiansposs + addtransposs;
            end
            %a1(a == 1) = certransposs + addtransposs;
            
        end
    else
          % uncertain edge 中没有non-exist
          [row,col] = find(a1);
          for i = 1:numel(row)
            a1(row(i), col(i))= certiansposs;
          end
         %a1(a == 1) = certransposs;
    end

    % undirected graph 
    %b = triu(a1)+triu(a1)';
    
    % column normalization
    n = size(a1,1);    % # of nodes
    d = full(sum(a1,2));      % in-degree vector
    % d(~d) = 1;
    % w = a1 / spdiags(d',0,n,n);
    d_inv = 1./d;
    d_inv(~isfinite(d_inv)) = 0;
    w = a1' * spdiags(d_inv, 0, n, n);
    flat_preCom_time = toc
    
    pprs = 0;
    memo = 0;
    tic
    for qu = 1: num_qu_set
        nqu = numel(qu_set{qu});
        qu_vec = sparse(qu_set{qu}', 1, 1/nqu, n, 1);
        [ppr, ppriterme] = iter_ppr(c, w, qu_vec, kmax);

        pprs = pprs+ppr;
        memo = max(memo, ppriterme);
    end
    ave_pprs = pprs/num_qu_set;

    flat_querytime = toc

    me = whos;
    bytes = [me.bytes].';
    flatme = sum(bytes) + memo
end
clear;
run("C:\Users\u5550119\OneDrive - University of Warwick\Documents\PageRank\metismex-master\metismex-master\METIS_startup.m");
addpath("C:\Users\u5550119\OneDrive - University of Warwick\Documents\PageRank\pageRank\matlab_UPPR\UPPR_mutual_exclusion\matlab_BLin");
%addpath("C:\Users\u5550119\OneDrive - University of Warwick\Documents\PageRank\pageRank\matlab_UPPR\UPPR_mutual_exclusion\")

fpath = 'C:\Users\u5550119\OneDrive - University of Warwick\Documents\PageRank\pageRank\datasets\';


fname = 'cit-HepPh';
% wiki-Vote cit-HepPh soc-LiveJournal1
% it-2004
% email-EuAll web-Stanford cit-Patents soc-LiveJournal1  webbase-2001
% uk-2002  arabic-2005  sk-2005
fn = [fpath, fname, '.mat'];

load(fn);
a = Problem.A;

%%%%%%%%%%%%%%%% hyperparameter %%%%%%%%%%%%%%%%%%%%%%%%
m = nnz(a);
n = size(a,2);
c = 0.8;
kmax = 100;
ncon = 1;
nparts = 5000;

%%%%%%%%%%%%%%%%% src tar qu %%%%%%%%%%%%%%%%%%%%%%%%%%%%
l = 6;
d = 4;

src_tarfpath = [fpath,'src_tar/','ds_',fname,'_l',int2str(l),'_d',int2str(d),'.mat'];
qufpath = [fpath,'qu/','ds_',fname,'_qu','.mat'];

src = load(src_tarfpath).src';

tar =  load(src_tarfpath).tar;

qu_set = load(qufpath).qu;

savefpath = '..\results\';
savefn = [savefpath, fname,'_l',int2str(l),'_d',int2str(d),'_res', '.mat'];
%save(savefn, 'l');
%%%%%%%%%%%%%%%%% PPR computation %%%%%%%%%%%%%%%%%%%%%%%%%%%%
exht = tic;
[res_exh, exhmem]  = exh_ppr_v1(a, src, tar, c, qu_set, kmax);
exh_time = toc(exht);
%save(savefn, "res_exh","-append")

exhApxt = tic;
%[res_exhApx, exhApxmem]= exhApx_ppr(a, c, qu_set, src, tar, ncon, nparts);
exhApx_time = toc(exhApxt)
%save(savefn, "res_exhApx","-append")

upprplust = tic;
%[res_upprplus, upprplusmem] = uppr_plus(a, c, qu_set, src, tar, fname);
upprplus_time=toc(upprplust);
% save(savefn, "res_upprplus","-append") 

collt = tic;
[res_coll_v2, collmem] = coll_ppr_v2(a, c, qu_set, src, tar, kmax);
coll_time = toc(collt);
save(savefn, "res_coll_v2","-append")

tic
%[res_flat,flatmem]=  flat_ppr(a, c, qu_set, src, tar, kmax);
flat_time = toc
save(savefn, "res_flat","-append")  

collApxt = tic;
%[res_collApxppr, collApxmem] = collApx_ppr(a, c, qu_set, src, tar,ncon,nparts);
collApx_time = toc(collApxt)
%save(savefn, "res_collApxppr","-append") 

collApx2t = tic;
%[collApx2,collApx2me] = collApx2_ppr(a, c, qu_set, src, tar,ncon,nparts);
collApx2_time = toc(collApx2t);
%save(savefn, "collApx2","-append")

flatApxt = tic;
%[res_flatApx, flatApxmem]= flatApx_ppr(a, c, qu_set, src, tar,ncon, nparts);
flatApx_time = toc(flatApxt)
%save(savefn, "res_flatApx","-append")

upprt = tic;
%[res_uppr, upprmem] = uppr(a, c, qu_set, ncon, nparts, src, tar);
uppr_time = toc(upprt);
%save(savefn, "res_uppr","-append") 


% %%%%%%%%%%% save results %%%%%%%%%%%%%%%%%
% alg = {'upprplus';'uppr';'BEAR';'exh'; 'exhApx';'coll'; 'collApx';'collApx2'; 'flat';'flatApx'};
% % %%%%%%%%%%% save time %%%%%%%%%%%%%%%%%%%%
% time = [upprplus_time; 0; 0; 0; 0; coll_time; 0; 0; flat_time; 0];
% filename = '..\excel_output\timeppr.xlsx';
% T1 = rows2vars(table(alg, time))
% 
% writetable(T1, filename, 'Sheet',1, 'Range','D1');
% 
% % %%%%%%%%%%% save memory %%%%%%%%%%%%%%%%%%%%
% memo = [upprplusmem; 0;  0; 0; 0; collmem;0; 0; flatmem;0];
% %exhmem, exhApxmem,collApx2mem,
% filename = '..\excel_output\memoryppr.xlsx';
% T2 = rows2vars(table(alg, memo))
% writetable(T2, filename, 'Sheet',1, 'Range','D1');

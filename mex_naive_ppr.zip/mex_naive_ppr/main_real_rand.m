clear;
run("C:\Users\u5550119\OneDrive - University of Warwick\Documents\PageRank\metismex-master\metismex-master\METIS_startup.m");
addpath("C:\Users\u5550119\OneDrive - University of Warwick\Documents\PageRank\pageRank\matlab_UPPR\UPPR_mutual_exclusion\matlab_BLin");
addpath("C:\Users\u5550119\OneDrive - University of Warwick\Documents\PageRank\pageRank\matlab_UPPR\UPPR_mutual_exclusion\")

fpath = 'C:\Users\u5550119\OneDrive - University of Warwick\Documents\PageRank\pageRank\datasets\';
fname = 'wiki-vote';
% soc-LiveJournal1
% it-2004
% email-EuAll web-Stanford cit-Patents soc-LiveJournal1 
% uk-2002  arabic-2005  sk-2005
fn = [fpath, fname, '.mat'];
savefn = [fname,'_res', '.mat'];
load(fn);
a = Problem.A;

nuc = 4;
src = randi(length(a),[1 nuc]);

degree = 4;
for i = 1 : nuc
    tar{i} = randi(length(a),[1 degree]);
end

qu_num = 3;
for i = 1:qu_num
    qu_set{i} = randi(length(a),[1 10]);
end

c = 0.8;
kmax = 50;

tic
res_exh = exh_ppr_v1(a, src, tar, c, qu_set, kmax);
toc

tic
res_upprplus = uppr_plus(a, c, qu_set, src, tar, fname);
toc

norm(res_exh-res_upprplus)

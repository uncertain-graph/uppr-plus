
clear

a = sparse([
    0	1	0	0	1
    0	0	1	1	0
    0	0	0	0	1
    0	0	1	0	0
    0	0	0	0	0
]);
g= digraph(a);
plot(g)
src = [2,3];
tar = {[1 5 0]
        [1,2,4,0]};
c = 0.8;
qu_set = {[2,4]};
kmax = 1000;

 res_exh = exh_ppr_v1(a, src, tar, c, qu_set, kmax);
tic
%res_coll_v2 = coll_ppr_v2(a, c, qu_set, src, tar, kmax);
toc
% tic
% res_flat = flat_ppr(a, c, qu_set, src, tar, kmax);
% toc
res_upprplus = uppr_plus(a, c, qu_set, src, tar, 'a');
% 
% tic
% res_coll_v1 = coll_ppr_v1(a, c, qu_set, src, tar, kmax);
% toc

% norm(res_exh-res_coll_v1)
% norm(res_exh-res_coll)
%res_coll_v2 = res_coll_v2/norm(res_coll_v2)
%[ave_pprs,  upprme] = uppr(a, c, qu_set, 1, 2, src, tar)
function [ave_qres, incme] = uppr_plus_v1(a, c, qu_set, src, tar, fname)
    num_qu_set = numel(qu_set);
    
    na = size(a,1); 
    ue_num = numel(src);
    ue_deg = numel(tar{1});
    
    l = numel(src);
    nsrc = numel(src);
    n = max([na, tar{:}]);
    m = nnz(a);
    a(n,n) = 0;
    if (n>na) 
       d(n,1) = 0;
    end

    fprintf('# of nodes = %d\n', n);
    fprintf('# of edges = %d\n', m);
    
    %%%%%%%%%%%%%% possible worlds %%%%%%%%%%%%%%%%%%%%%%
    % possible target sets 
    tar0 = cellfun(@(x) x, tar, 'UniformOutput', false);
    % tar0 = cellfun(@(x) [0 x], tar, 'UniformOutput', false); % add non-existence for each target node set. 
    tars = cell(1,nsrc);
    [tars{end:-1:1}] = ndgrid(tar0{end:-1:1}); 
    % tar0{end:-1:1} reverse; 
    % ndgrid replicates the grid vectors x1,x2,...,xn to produce an n-dimensional full grid.
    tars = cat(nsrc+1, tars{:});
    tars = reshape(tars,[],nsrc);  % npw x nsrc matrix
    
    %%%%%%%%%%%%%%%% index possible worlds %%%%%%%%%%%%%%
    time_total = tic;
    npw = size(tars,1);
    
    dict = containers.Map('KeyType', 'double', 'ValueType', 'double');
    for i = 1:l
        key = src(i);
        if isKey(dict, key)
            dict(key) = dict(key) + 1;  
        else
        dict(key) = 1;  
        end
    end
    uds = values(dict);
    ud = zeros(1,l);
    for i =1:l
        ud(i) = dict(src(i));
    end
    %ud = cat(2, uds{:});

    fprintf('\n== BEGIN pre-computing ==\n');
    time2 = tic;
    % same column norm as UPPR
    
    n = size(a,1);    % # of nodes
    d = full(sum(a,2));      % in-degree vector
    d_inv = 1./d;
    d_inv(~isfinite(d_inv)) = 0;
    q0 = a' *spdiags(d_inv, 0, n, n);

  
    clear a;
    
    %q0 is col_normed
    %r = inv(eye(n,n) - c*q0);
    
    % iterate ei 
    %%% r = ei*(I-cQ)^-1 pre-computing for the later indexing, containing
    %%% [(I-cQ)^-1]i,j , [(I-cQ)^-1]i,i and others.
    ei = sparse((1:nsrc)', src', ones(nsrc,1), nsrc, n);
    ei=full(ei);
    
    ilutime = tic;
    T = speye(n) - c * q0;
    [L,U] = ilu(T); 
    
    x = ei / U;
    r = x / L;
    lu_inv = toc(ilutime)
    
    r = full(r);  
    %R = inv(T);
    Dii = diag(d(src));
    %Dii = diag(src)
    period2 = toc(time2);
    fprintf('== END pre-computing ==\n');
    
    fprintf('\n== BEGIN online query ==\n');
    time3 = tic;
    
   qres = 0;
   for qu=1:num_qu_set
        nqu = numel(qu_set{qu});
        quvec = sparse(qu_set{qu}', 1, 1/nqu, n, 1);
        if (mod(qu, 1) == 0)
            fprintf(' query #%d\n', qu);
        end
        %p0 = iter_ppr(c, q0, quvec, 100)
        p0 = lu_ppr(L,U, quvec, c);

        %p0I = sparse(l,1);
        p0I = p0(src);

        l1 = ones(l,1);
        lambda_hw = sparse(l,1);
        nw = sparse(n,1);
   %%%%%%%% average hw, nw over pws %%%%%%%%%%%%%%%%%%%%%%%%     

        fprintf('Start ');
        for w = 1:npw
            if mod(w, ceil(npw/50)) == 0
                fprintf('.');
            end
            Jw = tars(w,:);
           
            Rij= r(:,Jw);
           
            lambdaRii = (l1*ud).*r(:,src);

            hw = (Dii-c*Rij+lambdaRii)\p0I;
           
            
            eta_w = sparse(Jw, 1, c*hw, n, 1);
         
            lambda_hw = lambda_hw + ud'.*hw;
            nw = nw + eta_w;
        end
        fprintf('\n');
    %%%%%%%% advancing aggregation end %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        hw = lambda_hw / npw;
        xi = sparse(src, 1, hw, n, 1);
        
        ave_nw = nw / npw;
        
        zeta = ave_nw - xi;
    
        pw = p0 + xi + (1/(1-c))*lu_ppr(L,U, zeta,c);
        res = full(pw);
        qres = qres + res;
   end
   
   ave_qres = qres/num_qu_set;
    %ave_qres = ave_qres/norm(ave_qres);
    
    period3 = toc(time3);
    fprintf('== END online query ==\n');
    period_total = toc(time_total);
    
    fprintf('\n\n========== total stats (UPPR+) ============\n\n');
    
    fprintf(' >>         dataset              :  %s \n', fname);
    fprintf(' >>      # of nodes              :  %d \n', n);
    fprintf(' >>      # of edges              :  %d \n\n', m);
    fprintf(' >>      # of uncertain edges  (source nodes)  :  %d \n\n', ue_num);
    fprintf(' >>      # of uncertain degree (target nodes for each uncertain edge) :  %d \n\n', ue_deg);
    
    fprintf(' >>  total CPU time              :  %fs \n', period_total);
    fprintf(' >>    2) pre-computing(lu_inv)          :  %fs  \n', period2); 
    fprintf(' >>    3) query                  :  %fs    (# of queries         : %d,    ave = %fs) \n', period3, num_qu_set, period3/num_qu_set);
    
    me = whos;
    bytes = [me.bytes].';
    incme = sum(bytes);
end